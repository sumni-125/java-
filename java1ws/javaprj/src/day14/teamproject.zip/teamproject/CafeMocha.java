package day14.teamproject;

public class CafeMocha implements Order{

	@Override
	public String Order() {
		String menu="카페모카";
		return menu;
	}

}
