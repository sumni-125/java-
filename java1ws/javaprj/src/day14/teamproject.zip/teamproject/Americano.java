package day14.teamproject;

public class Americano implements Order {

	@Override
	public String Order() {
		String menu = "아메리카노";
		return menu;
	}

}
