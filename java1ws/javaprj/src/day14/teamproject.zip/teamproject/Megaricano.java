package day14.teamproject;

public class Megaricano implements Order{

	@Override
	public String Order() {
		String menu="메가리카노";
		return menu;
	}

}
