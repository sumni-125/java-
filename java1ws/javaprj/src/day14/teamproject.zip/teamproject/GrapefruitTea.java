package day14.teamproject;

public class GrapefruitTea implements Order{

	@Override
	public String Order() {
		String menu="자몽차";
		return menu;
	}

}
