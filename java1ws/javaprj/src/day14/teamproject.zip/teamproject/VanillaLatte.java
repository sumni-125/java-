package day14.teamproject;

public class VanillaLatte implements Order{

	@Override
	public String Order() {
		String menu="바닐라라떼";
		return menu;
	}

}
