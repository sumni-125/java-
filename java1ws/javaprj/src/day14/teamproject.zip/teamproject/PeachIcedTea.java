package day14.teamproject;

public class PeachIcedTea implements Order{

	@Override
	public String Order() {
		String menu="복숭아 아이스티";
		return menu;
	}

}
