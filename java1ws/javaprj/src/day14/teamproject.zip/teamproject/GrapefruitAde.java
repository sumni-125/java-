package day14.teamproject;

public class GrapefruitAde implements Order{

	@Override
	public String Order() {
		String menu="자몽에이드";
		return menu;
	}

}
