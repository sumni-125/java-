package day14.teamproject;

public class StrawberryYogurtSmoothie implements Order{

	@Override
	public String Order() {
		String menu="카페라떼";
		return menu;
	}

}
