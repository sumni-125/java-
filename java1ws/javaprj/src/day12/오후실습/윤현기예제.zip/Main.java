package chap_08_interFace.Ex03;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
//      리스트자료형
        ArrayList<Shape> arrayList = new ArrayList<>();
        //         타입

        Rectangle rectangle1 = new Rectangle(5,3);
        Rectangle rectangle2 = new Rectangle(10,20);

        Circle circle1 = new Circle(3);
        Circle circle2 = new Circle(7);

        rectangle1.getArea();
        rectangle2.getArea();

        circle1.getArea();
        circle2.getArea();

        System.out.println("-----------어레이리스트 배열에 담기-------------");

        arrayList.add(rectangle1);
        arrayList.add(rectangle2);

        arrayList.add(circle1);
        arrayList.add(circle2);

        for (Shape shape : arrayList) {
            System.out.println(shape.toString());
        }

        // 오름차순으로 정렬하기
        //arrayList.sort(Comparator.naturalOrder());
    }
}
