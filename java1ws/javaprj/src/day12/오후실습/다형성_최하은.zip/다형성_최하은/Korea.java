package day12.다형성실습;

public class Korea extends Nation {
	@Override
	public void capital() {
		System.out.println("정답은 서울입니다.");
		super.capital();
	}
}
