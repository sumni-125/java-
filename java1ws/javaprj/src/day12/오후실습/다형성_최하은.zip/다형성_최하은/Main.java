package day12.다형성실습;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Nation ct = new Nation();
		Nation KR = new Korea();
		Spain ES = new Spain();
		England UK  = new England();
		Japan JP = new Japan();
		Portugal PRT = new Portugal();
		France FRA = new France();
		
		System.out.println("다음 나라들의 수도를 맞춰볼까요?");
		ct.capital();
		
		loop:while(true) {
			System.out.println("정답을 확인할 나라를 입력하세요.(끝 입력 시 종료)");
			String nation = sc.nextLine();
			
			switch(nation) {
			case "대한민국":
				KR.capital();
				break;
			case "스페인":
				ES.capital();
				break;
			case "영국":
				UK.capital();
				break;
			case "일본":
				JP.capital();
				break;
			case "포르투갈":
				PRT.capital();
				break;
			case "프랑스":
				FRA.capital();
				break;
			case "끝":
				System.out.println("끝~!");
				break loop;
			default:
				System.out.println("보기의 나라 중 입력하세요.");
				ct.capital();
			}
		}
		
		
		
	}

}
