package day12.다형성실습;

public class England extends Nation {
	@Override
	public void capital() {
		System.out.println("정답은 런던입니다.");
		super.capital();
	}
}
