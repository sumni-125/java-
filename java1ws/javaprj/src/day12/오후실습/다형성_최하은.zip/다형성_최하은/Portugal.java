package day12.다형성실습;

public class Portugal extends Nation {
	@Override
	public void capital() {
		System.out.println("정답은 리스본입니다.");
		super.capital();
	}
}
