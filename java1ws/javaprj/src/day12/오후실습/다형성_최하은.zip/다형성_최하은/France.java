package day12.다형성실습;

public class France extends Nation {
	@Override
	public void capital() {
		System.out.println("정답은 파리입니다.");
		super.capital();
	}
}
