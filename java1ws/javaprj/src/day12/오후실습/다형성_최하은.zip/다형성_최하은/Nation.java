package day12.다형성실습;

public class Nation {

	public void capital() {
		
		System.out.println("대한민국 스페인 영국 일본 포르투갈 프랑스");
	}
	
}
