package day12.다형성실습;

public class Spain extends Nation {
	@Override
	public void capital() {
		System.out.println("정답은 마드리드입니다.");
		super.capital();
	}
}
