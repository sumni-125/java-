package day12.실습;

public class Main {

	public static void main(String[] args) {
		User[] u = new User[3];
		u[0] = new User("홍길동", "user", "1234");
		u[1] = new User("유저", "user2", "2345");
		u[2] = new Admin("관리자", "admin", "123321", "URADM1N");

		userInfoPrint(u);
		System.out.println();
		권한확인하기(u[0]);
		System.out.println();
		권한확인하기(u[2]);
		System.out.println();
		u[0].권한();
		u = 관리자승급(u, 0);
		System.out.println();
		u[0].권한();
	}

	public static void userInfoPrint(User[] u) {
		for (User item : u) {
			if (item instanceof Admin) {
				Admin temp = (Admin) item;
				System.out.println(temp.toString());
			} else if (item instanceof User) {
				User temp = (User) item;
				System.out.println(temp.toString());
			}
		}
	}

	public static void 권한확인하기(User u) {
		if (u instanceof Admin) {
			Admin temp = (Admin) u;
			System.out.println("===관리자 권한입니다.===");
			temp.권한();
		} else if (u instanceof User) {
			User temp = (User) u;
			System.out.println("===유저 권한입니다.===");
			temp.권한();
		}
	}

	public static User[] 관리자승급(User[] u, int index) {
		Admin a = new Admin(u[index].getName(), u[index].getId(), u[index].getPw(), "N3WADMIN");
		u[index] = a;
		return u;
	}
}
