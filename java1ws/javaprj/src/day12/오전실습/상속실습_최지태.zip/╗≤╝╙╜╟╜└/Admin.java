package day12.실습;

public class Admin extends User {
	String code;

	public Admin(String name, String id, String pw, String code) {
		super(name, id, pw);
		this.code = code;
	}

	@Override
	public String toString() {
		return "관리자 " + " 이름 : " + name + " 아이디 : " + id + " 비밀번호 : " + pw + " 관리자코드 : " + code;
	}

	@Override
	public void 권한() {
		super.권한();
		System.out.println("모든 글 삭제하기");
		System.out.println("유저 관리하기");
	}
}
