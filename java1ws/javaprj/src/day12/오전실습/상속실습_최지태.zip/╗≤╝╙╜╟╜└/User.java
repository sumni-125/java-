package day12.실습;

public class User {
	String name;
	String id;
	String pw;

	public User(String name, String id, String pw) {
		this.name = name;
		this.id = id;
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getPw() {
		return pw;
	}

	public String toString() {
		return "고객  " + " 이름 : " + name + " 아이디 : " + id + " 비밀번호 : " + pw;
	}

	public void 권한() {
		System.out.println("글 쓰기");
		System.out.println("본인 글 삭제 하기");
	}
}
