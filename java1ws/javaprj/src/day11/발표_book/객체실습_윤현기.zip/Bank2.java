package chap_07.chap_01_class1.day01.Ex02;

// 4.접근제어자 관련 예제 만들기  ( private, public , default )
// 은행 프로그램
// ⭐️개설,조회,입금만 가능
public class Bank2 {
    private String ownerName;
    private int money;
    private int pwd;
    private int account;

    //⭐️이게 왜 필요한지 모르겠음
    public Bank2() {

    }

    public Bank2(String ownerName, int money, int pwd, int account) {
        this.ownerName = ownerName;
        this.money = money;
        this.pwd = pwd;
        this.account = account;
    }

    //입금 메서드
    private void deposit(int money) {
        if (money > 0) {
            account += money;
            System.out.println(ownerName + "님의 계좌에" + account + "만큼 입급 됐습니다");
        } else {
            System.out.println("올바른 금액을 입력해주세요.");
        }
    }

    // 비밀번호를 확인하는 메서드이자 비밀번호가 맞으면 입금 메서드를 호출
    public boolean checkPassword(int money, int inputPwd) {
        if (pwd != inputPwd) {
            System.out.println("올바른 비밀번호를 입력하세요.");
            return false;
        }

        deposit(money);
        return true;
    }

    // 계좌계설시 계좌에 있는 금액과 계좌주인의 값을 불러오기 위함
    // getter메서드
    public String getOwnerName() {
        return ownerName;
    }

    public int getAccount() {
        return account;
    }


    //출력하기 위한 메서드
    public String toString() {
        return ownerName + money + pwd + account;
    }

}