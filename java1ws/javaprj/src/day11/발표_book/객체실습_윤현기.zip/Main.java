package chap_07.chap_01_class1.day01.Ex02;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank2[] accounts = new Bank2[10];  // 최대 10개의 계좌 저장 가능
        int index = 0;

        while (true) {
            System.out.println("\n=== 은행 프로그램 ===");
            System.out.println("1. 계좌 개설");
            System.out.println("2. 입금하기");
            System.out.println("3. 전체 계좌 조회");
            System.out.println("4. 종료");
            System.out.print("선택> ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:  // 계좌 개설
                    System.out.println("\n== 계좌 개설 ==");

                    System.out.print("예금주 이름: ");
                    String ownerName = scanner.next();

                    System.out.print("초기 입금액: ");
                    int initialMoney = scanner.nextInt();

                    System.out.print("비밀번호 설정: ");
                    int pwd = scanner.nextInt();

                    accounts[index] = new Bank2(ownerName, initialMoney, pwd, initialMoney);
                    System.out.println(ownerName + "님의 계좌가 개설되었습니다.");
                    index++;
                    break;

                case 2:  // 입금하기
                    System.out.println("\n== 입금하기 ==");
                    System.out.println("입금할 계좌를 선택하세요:");
                    for (int i = 0; i < index; i++) {
                        System.out.println(i + ". " + accounts[i].getOwnerName() +
                                " (잔액: " + accounts[i].getAccount() + "원)");
                    }

                    System.out.print("계좌 번호 선택: ");
                    int accountNum = scanner.nextInt();

                    if (accountNum >= 0 && accountNum < index) {
                        System.out.print("입금액: ");
                        int depositAmount = scanner.nextInt();
                        System.out.print("비밀번호: ");
                        int inputPwd = scanner.nextInt();

                        if (accounts[accountNum].checkPassword(depositAmount, inputPwd)) {
                            System.out.println("입금이 완료되었습니다.");
                        }
                    } else {
                        System.out.println("잘못된 계좌 번호입니다.");
                    }
                    break;

                case 3:  // 전체 계좌 조회
                    System.out.println("\n== 전체 계좌 조회 ==");
                    if (index == 0) {
                        System.out.println("등록된 계좌가 없습니다.");
                    } else {
                        for (int i = 0; i < index; i++) {
                            System.out.println(i + ". " + accounts[i].toString());
                        }
                    }
                    break;

                case 4:  // 종료
                    System.out.println("프로그램을 종료합니다.");
                    scanner.close();
                    return;

                default:
                    System.out.println("잘못된 선택입니다. 다시 선택해주세요.");
            }
        }
    }
}

